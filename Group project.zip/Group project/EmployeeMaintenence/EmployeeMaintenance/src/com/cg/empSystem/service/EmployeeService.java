package com.cg.empSystem.service;

import java.util.List;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

public interface EmployeeService {
	UserMaster addUser(Employee emp) throws EmployeeException;
	List<String> getDeptname() throws EmployeeException;
	boolean removeEmployeeDetails(String employeeId) throws EmployeeException;
	boolean removeUserDetails(String userId) throws EmployeeException;
	List<Employee> showAllEmployee() throws EmployeeException;
	List<Employee> searchEmployeeOnFirstName(String firstName) throws EmployeeException;
	List<Employee> searchEmployeeOnLastName(String lastName) throws EmployeeException;
	List<Employee> searchEmployeeOnMaritalStatus(String maritalStatus) throws EmployeeException;
	int isValid(String userName, String userPassword) throws EmployeeException;
	List<Employee> SearchGrade(String grade) throws EmployeeException;
	List<Grade> getData(String grade) throws EmployeeException;
	public UserMaster getUserDetails(String userId) throws EmployeeException;
	UserMaster changePassword(UserMaster user) throws EmployeeException;
	public boolean updateEmp(Employee emp) throws EmployeeException;
	public Employee searchId(String id) throws EmployeeException;
	public Department getDeptName(int deptId ) throws EmployeeException;
	List<Employee> searchEmployeeOnDeptName(String deptName) throws EmployeeException;
	
}
